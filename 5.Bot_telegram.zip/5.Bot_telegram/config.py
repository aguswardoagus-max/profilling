# --- FILE: config.py ---
"""
Configuration file for MuaroNewsBot
"""

# Telegram Bot Configuration
# TODO: Isi dengan Bot Token dari @BotFather
BOT_TOKEN = "8287000069:AAEvVw6XnSrC9U-NNCgKuu0pP1gXY95jf3o"

# List of chat IDs where news will be sent
# TODO: Isi dengan Chat ID tujuan (bisa lebih dari satu)
# Untuk mendapatkan Chat ID, kirim pesan ke bot, lalu cek: https://api.telegram.org/bot<TOKEN>/getUpdates
TARGET_CHAT_IDS = []

# Default RSS sources (Google News for Muaro Jambi - multiple queries untuk hasil lebih banyak)
DEFAULT_SOURCES = [
    {
        "name": "Google News - Muaro Jambi",
        "url": "https://news.google.com/rss/search?q=Muaro+Jambi&hl=id&gl=ID&ceid=ID:id"
    },
    {
        "name": "Google News - Muaro Jambi (Berita Terkini)",
        "url": "https://news.google.com/rss/search?q=Muaro+Jambi+berita&hl=id&gl=ID&ceid=ID:id&when:24h"
    },
    {
        "name": "Google News - Muaro Jambi (Kota)",
        "url": "https://news.google.com/rss/search?q=%22Muaro+Jambi%22+kota&hl=id&gl=ID&ceid=ID:id&when:24h"
    },
    {
        "name": "Google News - Muaro Jambi (Kabupaten)",
        "url": "https://news.google.com/rss/search?q=%22Muaro+Jambi%22+kabupaten&hl=id&gl=ID&ceid=ID:id&when:24h"
    },
    {
        "name": "Google News - Muaro Jambi (Pemerintahan)",
        "url": "https://news.google.com/rss/search?q=Muaro+Jambi+pemerintah&hl=id&gl=ID&ceid=ID:id&when:24h"
    }
]

# Crawl interval in seconds (default: 24 hours = 86400 seconds)
FETCH_INTERVAL_SECONDS = 86400  # 24 jam sekali

# MySQL Database Configuration
# TODO: Isi dengan konfigurasi MySQL
DB_HOST = "localhost"
DB_PORT = 3306
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "muaronewsbot"

# OpenAI Configuration (optional - leave empty to disable summarization)
# TODO: Isi dengan OpenAI API Key jika ingin menggunakan fitur ringkasan artikel
OPENAI_API_KEY = ""
OPENAI_MODEL = "gpt-3.5-turbo"
OPENAI_MAX_TOKENS = 300  # Limit ringkasan ke 300 token

# Google Custom Search Engine (CSE) Configuration (optional - untuk berita lebih lengkap)
# Cara setup:
# 1. Buat API Key di: https://console.cloud.google.com/apis/credentials
# 2. Buat Custom Search Engine di: https://programmablesearchengine.google.com/
# 3. Set search type ke "Search the entire web" atau "Search specific sites"
# 4. Copy Search Engine ID (CX) dari pengaturan CSE
# 5. Enable Custom Search API di Google Cloud Console
# TODO: Isi dengan Google CSE API Key dan Search Engine ID
GOOGLE_CSE_API_KEY = "AIzaSyCzifk5yDIhhPq2HYo3EkcsOg-3xfMOZOU"
GOOGLE_CSE_ENGINE_ID = "7693f5093e95e4c28"  # CX parameter
GOOGLE_CSE_ENABLED = True  # Set True untuk mengaktifkan Google CSE

# Article content settings
MAX_ARTICLE_TEXT_CHARS = 15000  # Batas karakter teks artikel yang diambil (diperbesar untuk konten lebih lengkap)
MAX_ARTICLE_PARAGRAPHS = 100  # Maksimal jumlah paragraf yang diambil (diperbesar untuk konten lebih lengkap)

# Telegram settings
DISABLE_WEBPAGE_PREVIEW = True  # Disable link preview untuk pesan yang dikirim

# Telegram API timeout settings (dalam detik)
TELEGRAM_CONNECT_TIMEOUT = 30.0  # Timeout untuk koneksi ke Telegram API
TELEGRAM_READ_TIMEOUT = 30.0     # Timeout untuk membaca response dari Telegram API
TELEGRAM_WRITE_TIMEOUT = 30.0    # Timeout untuk menulis request ke Telegram API
TELEGRAM_POOL_TIMEOUT = 30.0     # Timeout untuk mendapatkan koneksi dari pool

