# --- FILE: news_bot.py ---
"""
MuaroNewsBot - Telegram Bot untuk crawling dan mengirim berita dari Google News RSS
"""
import logging
import json
import html
import re
import os
import asyncio
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional
from urllib.parse import urlparse, urljoin
import urllib.parse

import pymysql
import feedparser
import requests
from bs4 import BeautifulSoup
from dateutil import parser as date_parser
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, JobQueue, filters
from telegram.error import BadRequest

import config

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Global state
crawl_paused = False
current_job = None


def init_database():
    """Initialize MySQL database and create tables"""
    conn = get_connection()
    cursor = conn.cursor()
    
    # Table untuk menyimpan URL artikel yang sudah dikirim
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sent_articles (
            url VARCHAR(500) PRIMARY KEY,
            title TEXT,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')
    
    # Table untuk menyimpan sumber RSS
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sources (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            url VARCHAR(500) NOT NULL UNIQUE,
            enabled TINYINT DEFAULT 1,
            INDEX idx_enabled (enabled)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')
    
    # Seed default sources (selalu cek dan insert jika belum ada)
    for source in config.DEFAULT_SOURCES:
        cursor.execute(
            'INSERT IGNORE INTO sources (name, url, enabled) VALUES (%s, %s, 1)',
            (source['name'], source['url'])
        )
    
    conn.commit()
    conn.close()
    logger.info("Database initialized")


def get_connection():
    """Get MySQL database connection"""
    return pymysql.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        user=config.DB_USER,
        password=config.DB_PASSWORD,
        database=config.DB_NAME,
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )


def is_article_sent(url: str) -> bool:
    """Check if article URL has already been sent"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM sent_articles WHERE url = %s', (url,))
    result = cursor.fetchone() is not None
    conn.close()
    return result


def mark_article_sent(url: str, title: str):
    """Mark article URL as sent"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO sent_articles (url, title) VALUES (%s, %s) '
        'ON DUPLICATE KEY UPDATE title = %s, sent_at = CURRENT_TIMESTAMP',
        (url, title, title)
    )
    conn.commit()
    conn.close()


def parse_date(date_str: str) -> Optional[datetime]:
    """Parse date string using dateutil parser"""
    try:
        return date_parser.parse(date_str)
    except Exception as e:
        logger.warning(f"Failed to parse date '{date_str}': {e}")
        return None


def is_recent_article(published_date_str: str, hours: int = 24) -> bool:
    """
    Check apakah artikel diterbitkan dalam X jam terakhir
    Default: 24 jam terakhir
    """
    try:
        pub_date = parse_date(published_date_str)
        if not pub_date:
            # Jika tidak bisa parse date, anggap sebagai recent (untuk safety)
            return True
        
        # Pastikan timezone aware
        if pub_date.tzinfo is None:
            # Anggap sebagai UTC jika tidak ada timezone info
            pub_date = pub_date.replace(tzinfo=timezone.utc)
        
        now = datetime.now(timezone.utc)
        time_diff = now - pub_date
        
        # Cek apakah dalam X jam terakhir
        return time_diff <= timedelta(hours=hours)
    except Exception as e:
        logger.warning(f"Error checking recent article: {e}")
        # Jika error, anggap sebagai recent (untuk safety)
        return True


def is_valid_article_image(img_url: str, img_tag=None) -> bool:
    """
    Filter gambar yang relevan untuk artikel (bukan logo, icon, Google News, dll)
    """
    if not img_url:
        return False
    
    img_url_lower = img_url.lower()
    
    # BLOCK: Skip gambar dari Google News atau Google Services
    block_domains = [
        'news.google.com',
        'googleusercontent.com',
        'google.com',
        'gstatic.com',
        'googleapis.com'
    ]
    for domain in block_domains:
        if domain in img_url_lower:
            return False
    
    # BLOCK: Skip gambar yang jelas bukan artikel (logo, icon, favicon, dll)
    # Tapi lebih selektif - jangan terlalu agresif
    skip_keywords = [
        'favicon', 'avatar', 'profile',
        'facebook', 'twitter', 'instagram', 'youtube', 'whatsapp', 'social-share',
        'button', 'badge', 'sponsor', 'advertisement', 'ads',
        'pixel', 'tracker', 'analytics', '1x1', 'spacer', 'placeholder',
        'default', 'loading', 'spinner', 'widget', 'sidebar'
    ]
    
    # Skip jika URL mengandung keyword skip DAN tidak mengandung keyword article
    article_keywords = ['article', 'content', 'news', 'story', 'post', 'image', 'photo', 'picture']
    has_article_keyword = any(kw in img_url_lower for kw in article_keywords)
    
    for keyword in skip_keywords:
        if keyword in img_url_lower:
            # Jika ada artikel keyword juga, mungkin valid (e.g., article-banner)
            if not has_article_keyword:
                return False
    
    # BLOCK: Skip gambar terlalu kecil (kemungkinan icon/logo) - lebih fleksibel
    # Hanya block jika benar-benar kecil (kurang dari 100px)
    if img_tag:
        width = img_tag.get('width', '')
        height = img_tag.get('height', '')
        # Hanya block jika sangat kecil (kurang dari 100px) dan bukan dari path image
        if width and str(width).isdigit() and int(width) < 100:
            # Tapi allow jika dari path image yang jelas
            if not any(path in img_url_lower for path in ['/images/', '/img/', '/photos/', '/media/']):
                return False
        if height and str(height).isdigit() and int(height) < 100:
            # Tapi allow jika dari path image yang jelas
            if not any(path in img_url_lower for path in ['/images/', '/img/', '/photos/', '/media/']):
                return False
    
    # VALIDATE: Harus memiliki ekstensi gambar yang valid atau dari CDN image
    valid_extensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp']
    if any(ext in img_url_lower for ext in valid_extensions):
        return True
    
    # Bisa juga image dari CDN tanpa ekstensi jelas (contoh: image.jpg?size=large)
    if '?' in img_url and any(keyword in img_url_lower for keyword in ['image', 'img', 'photo', 'picture', 'media']):
        return True
    
    # Cek apakah URL mengandung path image (biasanya ada /images/, /img/, /photos/, dll)
    image_paths = ['/images/', '/img/', '/photos/', '/media/', '/assets/', '/uploads/']
    if any(path in img_url_lower for path in image_paths):
        return True
    
    return False


def fetch_article_image(url: str) -> Optional[str]:
    """
    Extract main article image URL dengan metode canggih
    Prioritaskan gambar artikel sebenarnya, bukan logo atau Google News
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        image_url = None
        candidates = []  # List untuk scoring
        
        # Method 1: Meta tags (prioritaskan ini karena biasanya paling akurat)
        meta_tags = [
            ('meta', {'property': 'og:image'}),
            ('meta', {'property': 'og:image:url'}),
            ('meta', {'property': 'article:image'}),
            ('meta', {'property': 'article:image:url'}),
            ('meta', {'name': 'twitter:image'}),
            ('meta', {'name': 'twitter:image:src'}),
            ('meta', {'property': 'og:image:secure_url'}),
            ('link', {'rel': 'image_src'}),
            ('link', {'rel': 'og:image'}),
        ]
        
        for tag_name, attrs in meta_tags:
            tag = soup.find(tag_name, attrs)
            if tag:
                img_src = tag.get('content') or tag.get('href') or tag.get('src')
                if img_src:
                    # Convert relative to absolute
                    if not img_src.startswith('http'):
                        img_src = urljoin(url, img_src)
                    if is_valid_article_image(img_src):
                        image_url = img_src
                        logger.info(f"✅ Found image from {tag_name} meta tag: {img_src[:80]}")
                        break
        
        # Method 2: Cari gambar di dalam article content (prioritas tinggi)
        if not image_url:
            # Cari container artikel dengan lebih banyak variasi
            article_selectors = [
                'article', 
                'main',
                'div[class*="article"]',
                'div[class*="content"]',
                'div[class*="post"]',
                'div[class*="entry"]',
                'div[class*="story"]',
                'div[class*="news"]',
                'div[id*="article"]',
                'div[id*="content"]',
            ]
            
            article_containers = []
            for selector in article_selectors[:5]:  # Coba beberapa selector
                try:
                    found = soup.select(selector)
                    article_containers.extend(found[:2])  # Max 2 per selector
                except:
                    continue
            
            # Juga cari dengan find_all seperti sebelumnya
            article_containers.extend(soup.find_all(['article', 'main', 'div'], class_=lambda x: x and any(
                keyword in str(x).lower() for keyword in ['article', 'content', 'post', 'entry', 'story', 'news', 'main', 'body']
            )))
            
            # Remove duplicates
            seen_containers = set()
            unique_containers = []
            for container in article_containers[:5]:
                container_id = id(container)
                if container_id not in seen_containers:
                    seen_containers.add(container_id)
                    unique_containers.append(container)
            
            for container in unique_containers:
                # Cari gambar dengan class/id yang menunjukkan featured/hero image
                featured_keywords = ['featured', 'hero', 'main', 'primary', 'cover', 'headline', 'thumbnail', 'lead', 'banner']
                featured_imgs = container.find_all('img', class_=lambda x: x and any(
                    keyword in str(x).lower() for keyword in featured_keywords
                ))
                
                # Juga cari berdasarkan ID
                featured_imgs.extend(container.find_all('img', id=lambda x: x and any(
                    keyword in str(x).lower() for keyword in featured_keywords
                )))
                
                if featured_imgs:
                    for img in featured_imgs:
                        src = (img.get('src') or 
                               img.get('data-src') or 
                               img.get('data-lazy-src') or 
                               img.get('data-original') or
                               img.get('data-lazy') or
                               img.get('data-url'))
                        if src:
                            if not src.startswith('http'):
                                src = urljoin(url, src)
                            if is_valid_article_image(src, img):
                                image_url = src
                                logger.info(f"✅ Found featured image in article: {src[:80]}")
                                break
                    if image_url:
                        break
                
                # Jika tidak ada featured, ambil gambar pertama yang cukup besar
                if not image_url:
                    for img in container.find_all('img', limit=15):  # Perbesar limit
                        src = (img.get('src') or 
                               img.get('data-src') or 
                               img.get('data-lazy-src') or 
                               img.get('data-original') or
                               img.get('data-lazy') or
                               img.get('data-url'))
                        if src:
                            if not src.startswith('http'):
                                src = urljoin(url, src)
                            if is_valid_article_image(src, img):
                                # Prioritaskan gambar dengan width/height besar
                                width = img.get('width', '')
                                if width and str(width).isdigit() and int(width) >= 300:  # Turunkan threshold
                                    image_url = src
                                    logger.info(f"✅ Found large image in article: {src[:80]}")
                                    break
                                elif not image_url:  # Fallback ke gambar pertama yang valid
                                    image_url = src
                    if image_url:
                        break
        
        # Method 3: Scoring system untuk semua gambar di page (LEBIH AGRESIF)
        if not image_url:
            all_images = soup.find_all('img')
            
            for img in all_images:
                # Coba semua atribut src yang mungkin (termasuk lazy loading)
                src = (img.get('src') or 
                       img.get('data-src') or 
                       img.get('data-lazy-src') or 
                       img.get('data-original') or 
                       img.get('data-url') or
                       img.get('data-srcset') or
                       img.get('srcset'))
                
                # Handle srcset (bisa multiple images)
                if src and ' ' in str(src):
                    src = str(src).split()[0]  # Ambil URL pertama dari srcset
                
                if not src:
                    continue
                
                # Convert relative URL to absolute
                src = urljoin(url, src)
                
                if not is_valid_article_image(src, img):
                    continue
                
                # Hitung score berdasarkan ukuran dan posisi
                score = 0
                
                # Prioritas berdasarkan ukuran (lebih agresif, terima gambar lebih kecil)
                width = img.get('width', '')
                height = img.get('height', '')
                if width and str(width).isdigit():
                    w = int(width)
                    if w >= 800:
                        score += 10
                    elif w >= 600:
                        score += 7
                    elif w >= 400:
                        score += 5
                    elif w >= 300:
                        score += 3
                if height and str(height).isdigit():
                    h = int(height)
                    if h >= 600:
                        score += 5
                    elif h >= 400:
                        score += 3
                
                # Prioritas berdasarkan class/id
                img_class = str(img.get('class', [])).lower()
                img_id = str(img.get('id', '')).lower()
                img_alt = str(img.get('alt', '')).lower()
                
                # Featured/hero images mendapat score tinggi
                if any(kw in img_class or kw in img_id for kw in ['featured', 'hero', 'main', 'primary', 'cover', 'lead', 'banner']):
                    score += 20
                # Article images
                if any(kw in img_class or kw in img_id for kw in ['article', 'content', 'post', 'story']):
                    score += 10
                # Image keywords
                if any(kw in img_class or kw in img_id for kw in ['image', 'photo', 'picture', 'thumbnail']):
                    score += 5
                # Alt text yang relevan
                if img_alt and len(img_alt) > 10 and not any(skip in img_alt for skip in ['logo', 'icon', 'button']):
                    score += 3
                
                # Prioritas berdasarkan parent element
                parent = img.find_parent()
                if parent:
                    parent_class = str(parent.get('class', [])).lower()
                    if any(kw in parent_class for kw in ['article', 'content', 'main', 'featured']):
                        score += 10
                
                # Prioritas berdasarkan posisi (gambar di awal artikel biasanya lebih penting)
                if img.find_parent('article') or img.find_parent('main'):
                    score += 5
                
                candidates.append((score, src))
            
            # Ambil gambar dengan score tertinggi
            if candidates:
                candidates.sort(reverse=True, key=lambda x: x[0])
                image_url = candidates[0][1]
                logger.info(f"Found best candidate image (score {candidates[0][0]}): {image_url[:80]}")
        
        # Convert relative URLs to absolute
        if image_url:
            if image_url.startswith('//'):
                image_url = 'https:' + image_url
            elif image_url.startswith('/'):
                image_url = urljoin(url, image_url)
            elif not image_url.startswith('http'):
                # Relative path tanpa leading slash
                base_url = '/'.join(url.split('/')[:-1])
                image_url = urljoin(base_url + '/', image_url)
            
            # Validasi akhir - pastikan tidak dari Google News
            if 'news.google.com' in image_url.lower() or 'googleusercontent.com' in image_url.lower():
                logger.warning(f"Skipping Google News image: {image_url[:80]}")
                return None
            
            # Pastikan URL lengkap (jika masih relatif, convert)
            if not image_url.startswith('http'):
                image_url = urljoin(url, image_url)
            
            logger.info(f"✅ Final image URL: {image_url[:100]}")
            return image_url
        
        return None
    
    except Exception as e:
        logger.warning(f"Failed to fetch article image from {url}: {e}")
        return None


def fetch_article_text(url: str) -> str:
    """
    Fetch and extract full text content from article URL using BeautifulSoup
    Returns complete article text dengan metode yang lebih agresif untuk konten lengkap
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        response = requests.get(url, headers=headers, timeout=20, allow_redirects=True)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Remove script, style, dan elemen yang tidak perlu
        for unwanted in soup(["script", "style", "meta", "link", "nav", "header", "footer", "aside", "menu", "iframe", "form", "button", "noscript"]):
            unwanted.decompose()
        
        article_text = ""
        seen_texts = set()  # Hindari duplikasi
        
        # Method 1: Cari dengan selector yang lebih spesifik untuk artikel
        article_selectors = [
            'article',
            'main article',
            '[role="article"]',
            '.article-content',
            '.article-body',
            '.post-content',
            '.entry-content',
            '.story-content',
            '.news-content',
            '#article-content',
            '#article-body',
            '#content article',
            'main',
            '[itemprop="articleBody"]',
            '.content article',
            '.main-content'
        ]
        
        for selector in article_selectors:
            try:
                containers = soup.select(selector)
                for container in containers[:3]:  # Ambil 3 container pertama
                    paragraphs = container.find_all(['p', 'div', 'span', 'li', 'blockquote', 'h2', 'h3', 'h4', 'h5', 'section'])
                    for p in paragraphs:
                        text = p.get_text(strip=True, separator=' ')
                        if text and len(text) > 30:  # Minimal 30 karakter
                            # Skip elemen yang jelas bukan konten
                            text_lower = text.lower()
                            if any(skip in text_lower for skip in [
                                'cookie', 'privacy', 'terms', 'subscribe', 'newsletter', 
                                'follow us', 'share this', 'read more', 'related articles',
                                'komentar', 'comment', 'login', 'register', 'sign up',
                                'advertisement', 'iklan', 'sponsor'
                            ]):
                                continue
                            
                            # Skip duplikat
                            text_hash = text[:100].lower().strip()
                            if text_hash in seen_texts:
                                continue
                            seen_texts.add(text_hash)
                            
                            # Pastikan mengandung huruf
                            if any(c.isalpha() for c in text):
                                article_text += text + "\n\n"
                                if len(article_text) > config.MAX_ARTICLE_TEXT_CHARS:
                                    break
                    if len(article_text) > config.MAX_ARTICLE_TEXT_CHARS:
                        break
                if len(article_text) > 500:  # Jika sudah dapat cukup, stop
                    break
            except Exception:
                continue
        
        # Method 2: Jika masih kurang, cari semua paragraf dengan class/id yang relevan
        if len(article_text) < 500:
            all_paragraphs = soup.find_all(['p', 'div'], class_=lambda x: x and any(
                keyword in str(x).lower() for keyword in [
                    'article', 'content', 'post', 'entry', 'story', 'news', 
                    'body', 'text', 'paragraph', 'description', 'detail'
                ]
            ))
            
            for p in all_paragraphs[:100]:  # Ambil 100 paragraf pertama
                text = p.get_text(strip=True, separator=' ')
                if text and len(text) > 30:
                    text_lower = text.lower()
                    if any(skip in text_lower for skip in [
                        'cookie', 'privacy', 'terms', 'subscribe', 'newsletter',
                        'follow us', 'share this', 'read more', 'related',
                        'komentar', 'comment', 'login', 'register', 'advertisement'
                    ]):
                        continue
                    
                    text_hash = text[:100].lower().strip()
                    if text_hash in seen_texts:
                        continue
                    seen_texts.add(text_hash)
                    
                    if any(c.isalpha() for c in text):
                        article_text += text + "\n\n"
                        if len(article_text) > config.MAX_ARTICLE_TEXT_CHARS:
                            break
        
        # Method 3: Fallback - ambil dari body dengan filter yang lebih baik
        if len(article_text) < 300:
            body = soup.find('body')
            if body:
                # Hapus elemen yang tidak perlu
                for unwanted in body.find_all(['script', 'style', 'nav', 'header', 'footer', 'aside', 'menu', 'iframe', 'form', 'button', 'noscript', 'svg']):
                    unwanted.decompose()
                
                # Ambil semua paragraf dari body
                all_p = body.find_all(['p', 'div', 'span', 'article', 'section'])
                for p in all_p[:150]:  # Ambil 150 elemen pertama
                    text = p.get_text(strip=True, separator=' ')
                    if text and len(text) > 40:  # Minimal 40 karakter
                        text_lower = text.lower()
                        # Skip jika jelas bukan konten artikel
                        if any(skip in text_lower for skip in [
                            'cookie', 'privacy', 'terms', 'subscribe', 'newsletter',
                            'follow us', 'share', 'read more', 'related', 'komentar',
                            'comment', 'login', 'register', 'sign up', 'advertisement',
                            'iklan', 'sponsor', 'trending', 'popular', 'most read'
                        ]):
                            continue
                        
                        text_hash = text[:100].lower().strip()
                        if text_hash in seen_texts:
                            continue
                        seen_texts.add(text_hash)
                        
                        if any(c.isalpha() for c in text) and len(text) > 40:
                            article_text += text + "\n\n"
                            if len(article_text) > config.MAX_ARTICLE_TEXT_CHARS:
                                break
        
        # Clean up: hapus baris kosong berlebihan dan format ulang
        if article_text:
            lines = []
            for line in article_text.split('\n'):
                line = line.strip()
                if line and len(line) > 20:  # Minimal 20 karakter per baris
                    if any(c.isalpha() for c in line):
                        lines.append(line)
            article_text = '\n\n'.join(lines)
        
        # Limit to MAX_ARTICLE_TEXT_CHARS
        if len(article_text) > config.MAX_ARTICLE_TEXT_CHARS:
            article_text = article_text[:config.MAX_ARTICLE_TEXT_CHARS] + "..."
        
        return article_text.strip()
    
    except Exception as e:
        logger.error(f"Failed to fetch article text from {url}: {e}")
        return ""


def summarize_with_openai(text: str) -> Optional[str]:
    """
    Summarize article text using OpenAI API
    Returns summary limited to OPENAI_MAX_TOKENS tokens
    """
    if not config.OPENAI_API_KEY:
        return None
    
    try:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {config.OPENAI_API_KEY}",
            "Content-Type": "application/json"
        }
        data = {
            "model": config.OPENAI_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": "Anda adalah asisten yang merangkum artikel berita dalam bahasa Indonesia dengan singkat dan padat."
                },
                {
                    "role": "user",
                    "content": f"Ringkas artikel berikut dalam maksimal 300 kata:\n\n{text[:3000]}"  # Limit input text
                }
            ],
            "max_tokens": config.OPENAI_MAX_TOKENS,
            "temperature": 0.7
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        summary = result.get('choices', [{}])[0].get('message', {}).get('content', '')
        
        return summary.strip() if summary else None
    
    except Exception as e:
        logger.error(f"OpenAI summarization failed: {e}")
        return None


def format_message(entry: Dict, article_text: str = "", summary: Optional[str] = None, is_caption: bool = False) -> tuple[str, Optional[InlineKeyboardMarkup]]:
    """
    Format news entry as HTML message untuk Telegram dengan format list yang rapi dan jelas
    Telegram caption limit: 1024 characters (jika dengan foto)
    Telegram text limit: 4096 characters (jika tanpa foto)
    """
    title = html.escape(entry.get('title', 'Tanpa Judul'))
    link = entry.get('link', '#')
    # Pastikan link valid dan bisa dibuka
    if not link or link == '#' or not link.startswith('http'):
        # Coba ambil dari entry langsung jika link tidak valid
        link = entry.get('link', '') or entry.get('url', '#')
    
    # Decode URL jika perlu
    try:
        link = urllib.parse.unquote(link)
    except:
        pass
    
    published = entry.get('published', '')
    
    # Parse and format date dengan format sederhana
    pub_date = parse_date(published)
    if pub_date:
        # Hitung waktu relatif
        now = datetime.now(timezone.utc)
        if pub_date.tzinfo is None:
            pub_date = pub_date.replace(tzinfo=timezone.utc)
        time_diff = now - pub_date
        hours_ago = int(time_diff.total_seconds() / 3600)
        minutes_ago = int((time_diff.total_seconds() % 3600) / 60)
        days_ago = time_diff.days
        
        if days_ago > 0:
            relative_time = f"{days_ago} hari lalu"
        elif hours_ago > 0:
            relative_time = f"{hours_ago} jam lalu"
        elif minutes_ago > 0:
            relative_time = f"{minutes_ago} menit lalu"
        else:
            relative_time = "baru saja"
    else:
        relative_time = published if published else "Waktu tidak diketahui"
    
    source = html.escape(entry.get('source', {}).get('title', entry.get('source_name', 'Sumber Tidak Dikenal')))
    
    header = f"📰 <b>{title}</b>\n\n"
    
    # Hitung space yang tersedia untuk konten
    # Format sederhana: judul + ringkasan singkat + source + waktu + link
    header_len = len(header.replace('<b>', '').replace('</b>', '').replace('<i>', '').replace('</i>', ''))
    footer_len = 100  # Footer sederhana dengan link
    # Pilih max length berdasarkan apakah ini caption atau text message
    max_content_len = (800 - header_len - footer_len) if is_caption else (3000 - header_len - footer_len)
    
    content = ""
    
    if summary:
        neat = clean_narrative_text(summary.strip())
        neat = neat if neat else summary.strip()
        neat = html.escape(neat)
        if len(neat) > max_content_len:
            neat = neat[:max_content_len - 50] + "..."
        content = f"{neat}\n\n"
    elif article_text and len(article_text.strip()) > 20:
        clean_text = clean_narrative_text(article_text)
        if len(clean_text) > 50:
            paragraphs = [p.strip() for p in clean_text.split('\n\n') if p.strip()]
            max_paras = 2 if is_caption else 3
            resume_text = '\n\n'.join(paragraphs[:max_paras]) if paragraphs else clean_text
            resume_text = html.escape(resume_text)
            if len(resume_text) > max_content_len:
                resume_text = resume_text[:max_content_len - 50] + "..."
            content = f"{resume_text}\n\n"
        else:
            content = f"{html.escape(clean_text)}\n\n"
    else:
        rss_summary = entry.get('summary', '') or entry.get('description', '')
        if rss_summary:
            clean_summary = clean_narrative_text(rss_summary).strip()
            if len(clean_summary) > 30:
                summary_text = html.escape(clean_summary[:max_content_len])
                content = f"{summary_text}\n\n"
    
    link_line = f"🔗 <a href='{html.escape(link)}'>Baca lengkap</a>"
    message = header + content + link_line
    
    # Buat inline keyboard dengan tombol link yang bisa langsung dibuka (tanpa dialog)
    keyboard = [
        [InlineKeyboardButton("🔗 Baca Artikel Lengkap", url=link)]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Final check dan trim jika perlu (sesuai apakah caption atau text message)
    # Telegram limit: 1024 untuk caption, 4096 untuk text
    # Hitung panjang tanpa HTML tags untuk akurasi
    def strip_html(text):
        return re.sub(r'<[^>]+>', '', text)
    
    message_len = len(strip_html(message))
    max_msg_len = 1020 if is_caption else 4080  # Maksimalkan untuk text message agar lebih lengkap
    
    if message_len > max_msg_len:
        excess = message_len - max_msg_len
        if content:
            # Potong dari content
            content_stripped = strip_html(content)
            if len(content_stripped) > excess + 50:
                # Potong dari akhir content
                content_lines = content.split('\n\n')
                if len(content_lines) > 1:
                    # Potong dari paragraf terakhir
                    last_para = content_lines[-2] if len(content_lines) > 2 else content_lines[-1]
                    last_para_stripped = strip_html(last_para)
                    if len(last_para_stripped) > excess + 100:
                        # Potong paragraf terakhir
                        para_escaped = html.escape(last_para_stripped)
                        new_para = para_escaped[:len(para_escaped) - excess - 20] + "..."
                        content_lines[-2] = new_para if len(content_lines) > 2 else new_para
                        content = '\n\n'.join(content_lines)
                    else:
                        # Hapus paragraf terakhir
                        content = '\n\n'.join(content_lines[:-1]) + "\n\n"
                message = header + content + footer
    
    return message, reply_markup


def fetch_google_cse_news(query: str = "Muaro Jambi", max_results: int = 10) -> List[Dict]:
    """
    Fetch news from Google Custom Search Engine API
    Returns list of news entries dengan link dan gambar langsung
    Filter: Berita 24 jam terakhir
    """
    if not config.GOOGLE_CSE_ENABLED or not config.GOOGLE_CSE_API_KEY or not config.GOOGLE_CSE_ENGINE_ID:
        return []
    
    try:
        # Google CSE API endpoint
        url = "https://www.googleapis.com/customsearch/v1"
        
        all_results = []
        
        # Google CSE bisa return maksimal 10 hasil per request
        # Jika butuh lebih, perlu multiple requests dengan start parameter
        for start in range(1, max_results + 1, 10):
            # Build params dengan hanya parameter yang valid
            params = {
                'key': config.GOOGLE_CSE_API_KEY,
                'cx': config.GOOGLE_CSE_ENGINE_ID,
                'q': query,  # Gunakan query asli tanpa tambahan "berita"
                'num': min(10, max_results - start + 1),  # Max 10 per request
                'start': start,
                'dateRestrict': 'd1',  # Last 1 day (24 jam terakhir)
                'safe': 'active'
            }
            
            # Hapus parameter yang tidak valid atau kosong
            # Jangan kirim parameter fileType, searchType, lr, gl yang kosong atau tidak didukung
            
            response = requests.get(url, params=params, timeout=30)
            
            # Cek response status dengan error handling yang lebih baik
            if response.status_code != 200:
                try:
                    error_data = response.json()
                    error_msg = error_data.get('error', {}).get('message', f'HTTP {response.status_code}')
                    logger.warning(f"Google CSE API error for query '{query}': {error_msg}")
                except:
                    logger.warning(f"Google CSE API error for query '{query}': HTTP {response.status_code}")
                # Skip query ini, lanjut ke query berikutnya atau break
                break
            
            data = response.json()
            items = data.get('items', [])
            
            if not items:
                break
            
            for item in items:
                # Extract data dari Google CSE response
                title = item.get('title', '')
                link = item.get('link', '')
                snippet = item.get('snippet', '')
                display_link = item.get('displayLink', '')
                
                # Extract image dari pagemap jika ada
                image_url = None
                pagemap = item.get('pagemap', {})
                
                # Cari gambar dari berbagai sumber di pagemap
                if pagemap:
                    # Cek cse_image
                    if 'cse_image' in pagemap and pagemap['cse_image']:
                        img_list = pagemap['cse_image']
                        if isinstance(img_list, list) and len(img_list) > 0:
                            image_url = img_list[0].get('src', '') if isinstance(img_list[0], dict) else str(img_list[0])
                    
                    # Cek metatags untuk og:image
                    if not image_url and 'metatags' in pagemap and pagemap['metatags']:
                        meta_list = pagemap['metatags']
                        if isinstance(meta_list, list) and len(meta_list) > 0:
                            meta = meta_list[0] if isinstance(meta_list[0], dict) else {}
                            image_url = (meta.get('og:image') or 
                                        meta.get('twitter:image') or 
                                        meta.get('image') or
                                        meta.get('og:image:url'))
                    
                    # Cek cse_thumbnail
                    if not image_url and 'cse_thumbnail' in pagemap and pagemap['cse_thumbnail']:
                        thumb_list = pagemap['cse_thumbnail']
                        if isinstance(thumb_list, list) and len(thumb_list) > 0:
                            image_url = thumb_list[0].get('src', '') if isinstance(thumb_list[0], dict) else str(thumb_list[0])
                
                # Pastikan image URL valid
                if image_url:
                    if not image_url.startswith('http'):
                        image_url = None
                    elif 'googleusercontent.com' in image_url.lower() or 'gstatic.com' in image_url.lower():
                        # Skip Google images
                        image_url = None
                
                # Buat entry dict
                entry = {
                    'title': title,
                    'link': link,
                    'published': datetime.now(timezone.utc).isoformat(),  # Google CSE tidak provide exact date, anggap baru
                    'source': {'title': display_link or 'Google News'},
                    'summary': snippet,
                    'description': snippet,
                    'source_name': 'Google CSE',
                    'image_url': image_url  # Simpan image URL langsung dari CSE
                }
                
                all_results.append(entry)
            
            # Jika hasil kurang dari 10, berarti sudah habis
            if len(items) < 10:
                break
        
        logger.info(f"✅ Google CSE: Fetched {len(all_results)} results for query '{query}'")
        return all_results
    
    except Exception as e:
        logger.error(f"Failed to fetch from Google CSE: {e}")
        return []


def fetch_feeds() -> List[Dict]:
    """
    Fetch and parse all enabled RSS feeds dengan error handling yang lebih baik
    Juga fetch dari Google CSE jika diaktifkan
    Returns list of news entries
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, name, url FROM sources WHERE enabled = 1')
    sources = cursor.fetchall()
    conn.close()
    
    all_entries = []
    failed_sources = []
    
    # Fetch dari Google CSE jika diaktifkan
    if config.GOOGLE_CSE_ENABLED and config.GOOGLE_CSE_API_KEY and config.GOOGLE_CSE_ENGINE_ID:
        try:
            cse_queries = [
                "Muaro Jambi",
                "Muaro Jambi berita",
                '"Muaro Jambi" kota',
                '"Muaro Jambi" kabupaten',
                "Muaro Jambi pemerintah"
            ]
            
            for query in cse_queries:
                cse_results = fetch_google_cse_news(query, max_results=10)
                for entry in cse_results:
                    # Skip duplicate berdasarkan URL
                    if not any(e['link'] == entry['link'] for e in all_entries):
                        all_entries.append(entry)
            
            logger.info(f"✅ Google CSE: Added {len([e for e in all_entries if e.get('source_name') == 'Google CSE'])} entries")
        except Exception as e:
            logger.error(f"Error fetching from Google CSE: {e}")
    
    for source_row in sources:
        source_id = source_row['id']
        source_name = source_row['name']
        source_url = source_row['url']
        try:
            # Gunakan requests dengan headers yang lebih baik untuk menghindari 400 error
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/rss+xml, application/xml, text/xml, */*',
                'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Cache-Control': 'max-age=0'
            }
            
            # Fetch dengan requests terlebih dahulu untuk handle error dengan lebih baik
            response = requests.get(source_url, headers=headers, timeout=30, allow_redirects=True)
            
            # Cek status code
            if response.status_code == 400:
                logger.warning(f"400 Bad Request untuk {source_name} ({source_url})")
                # Coba decode URL dan gunakan format alternatif
                try:
                    # Coba dengan parameter yang berbeda
                    if 'news.google.com' in source_url:
                        # Untuk Google News, coba tanpa beberapa parameter
                        alt_url = source_url.replace('&when:24h', '').replace('when:24h', '')
                        response = requests.get(alt_url, headers=headers, timeout=30, allow_redirects=True)
                        if response.status_code == 200:
                            logger.info(f"Berhasil dengan URL alternatif untuk {source_name}")
                        else:
                            failed_sources.append(source_name)
                            continue
                    else:
                        failed_sources.append(source_name)
                        continue
                except Exception as alt_err:
                    logger.error(f"Error mencoba URL alternatif untuk {source_name}: {alt_err}")
                    failed_sources.append(source_name)
                    continue
            
            if response.status_code != 200:
                logger.warning(f"Status code {response.status_code} untuk {source_name} ({source_url})")
                failed_sources.append(source_name)
                continue
            
            # Parse feed dengan feedparser
            feed = feedparser.parse(response.content)
            
            if feed.bozo and feed.bozo_exception:
                logger.warning(f"Feed parsing error for {source_name} ({source_url}): {feed.bozo_exception}")
                # Tetap coba parse meskipun ada warning
            
            if not feed.entries:
                logger.warning(f"Tidak ada entry ditemukan di {source_name}")
                continue
            
            entry_count = 0
            for entry in feed.entries:
                # Google News RSS format
                link = entry.get('link', '')
                # Extract actual URL from Google News redirect URL
                if 'url?q=' in link:
                    match = re.search(r'url\?q=([^&]+)', link)
                    if match:
                        link = urllib.parse.unquote(match.group(1))
                
                # Pastikan link valid
                if not link or not link.startswith('http'):
                    continue
                
                entry_dict = {
                    'title': entry.get('title', ''),
                    'link': link,
                    'published': entry.get('published', ''),
                    'source': entry.get('source', {}),
                    'summary': entry.get('summary', ''),
                    'description': entry.get('description', entry.get('summary', '')),
                    'source_name': source_name  # Tambahkan nama sumber
                }
                
                # Skip duplicate entries (berdasarkan URL)
                if not any(e['link'] == link for e in all_entries):
                    all_entries.append(entry_dict)
                    entry_count += 1
            
            logger.info(f"✅ {source_name}: {entry_count} entries")
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error untuk {source_name} ({source_url}): {e}")
            failed_sources.append(source_name)
        except Exception as e:
            logger.error(f"Failed to fetch feed {source_name} ({source_url}): {e}")
            failed_sources.append(source_name)
    
    if failed_sources:
        logger.warning(f"⚠️ {len(failed_sources)} sumber gagal: {', '.join(failed_sources)}")
    
    # Sort by published date (newest first) dan remove duplicates
    seen_urls = set()
    unique_entries = []
    for entry in all_entries:
        url = entry['link']
        if url and url not in seen_urls:
            seen_urls.add(url)
            unique_entries.append(entry)
    
    # Fetch dari Google CSE jika diaktifkan (setelah RSS untuk menghindari duplikasi)
    if config.GOOGLE_CSE_ENABLED and config.GOOGLE_CSE_API_KEY and config.GOOGLE_CSE_ENGINE_ID:
        try:
            # Gunakan query yang lebih sederhana untuk menghindari error
            cse_queries = [
                "Muaro Jambi",
                "Muaro Jambi berita"
            ]
            
            cse_entries = []
            for query in cse_queries:
                try:
                    cse_results = fetch_google_cse_news(query, max_results=10)
                    for entry in cse_results:
                        # Skip duplicate berdasarkan URL (cek dengan RSS entries juga)
                        if not any(e['link'] == entry['link'] for e in unique_entries):
                            if not any(e['link'] == entry['link'] for e in cse_entries):
                                cse_entries.append(entry)
                except Exception as query_err:
                    logger.warning(f"Google CSE query '{query}' failed: {query_err}")
                    continue  # Lanjut ke query berikutnya
            
            # Tambahkan CSE entries ke unique_entries
            if cse_entries:
                unique_entries.extend(cse_entries)
                logger.info(f"✅ Google CSE: Added {len(cse_entries)} new entries (total CSE: {len([e for e in unique_entries if e.get('source_name') == 'Google CSE'])})")
            else:
                logger.info(f"⚠️ Google CSE: No new entries found (mungkin quota habis atau error)")
        except Exception as e:
            logger.error(f"Error fetching from Google CSE: {e}")
    
    # Sort by date (newest first) - ulang setelah tambah CSE entries
    unique_entries.sort(
        key=lambda x: parse_date(x.get('published', '')) or datetime.min.replace(tzinfo=timezone.utc), 
        reverse=True
    )
    
    logger.info(f"✅ Fetched {len(unique_entries)} unique entries from {len(sources) - len(failed_sources)}/{len(sources)} RSS sources" + 
                (f" + {len([e for e in unique_entries if e.get('source_name') == 'Google CSE'])} CSE entries" if config.GOOGLE_CSE_ENABLED else ""))
    return unique_entries


async def send_news_to_chats(context: ContextTypes.DEFAULT_TYPE, message: str, image_url: Optional[str] = None, reply_markup: Optional[InlineKeyboardMarkup] = None):
    """Kirim satu pesan teks dengan preview link agar foto tampil di atas"""
    if not config.TARGET_CHAT_IDS:
        logger.warning("No target chat IDs configured")
        return
    
    for chat_id in config.TARGET_CHAT_IDS:
        try:
            await context.bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode='HTML',
                disable_web_page_preview=False,
                reply_markup=reply_markup
            )
            logger.info(f"Sent single-card news to chat {chat_id}")
        except Exception as e:
            logger.error(f"Failed to send message to chat {chat_id}: {e}")

def _split_text_chunks(text: str, max_len: int = 3900) -> List[str]:
    text = text.strip()
    if not text:
        return []
    paragraphs = [p for p in text.split('\n\n') if p.strip()]
    chunks: List[str] = []
    current = ""
    for p in paragraphs:
        p = p.strip()
        sep = "\n\n" if current else ""
        if len(html.escape(current + sep + p)) <= max_len:
            current = current + sep + p
        else:
            if current:
                chunks.append(current)
                current = ""
            # If single paragraph too long, hard split
            part = p
            while len(html.escape(part)) > max_len:
                cut = max_len - 50
                chunks.append(part[:cut])
                part = part[cut:]
            current = part
    if current:
        chunks.append(current)
    return chunks

def clean_narrative_text(text: str) -> str:
    if not text:
        return ""
    t = re.sub(r'<[^>]+>', '', text)
    t = t.replace('\r', '')
    blocks = [b.strip() for b in t.split('\n\n') if b.strip()]
    cleaned = []
    for b in blocks:
        b = re.sub(r'\s+', ' ', b).strip()
        b = re.sub(r'([.!?])([A-Za-z0-9])', r'\1 \2', b)
        cleaned.append(b)
    return '\n\n'.join(cleaned)

async def send_full_article_text(context: ContextTypes.DEFAULT_TYPE, chat_id: int, title: str, article_text: str):
    try:
        clean_text = clean_narrative_text(article_text or '').strip()
        if not clean_text:
            return
        header = f"📖 <b>Narasi Lengkap:</b> <i>{html.escape(title[:120])}{'...' if len(title) > 120 else ''}</i>\n\n"
        chunks = _split_text_chunks(clean_text, max_len=3900 - len(html.escape(header)))
        if not chunks:
            return
        first = header + html.escape(chunks[0])
        await context.bot.send_message(
            chat_id=chat_id,
            text=first,
            parse_mode='HTML',
            disable_web_page_preview=True
        )
        for chunk in chunks[1:]:
            await asyncio.sleep(0.2)
            await context.bot.send_message(
                chat_id=chat_id,
                text=html.escape(chunk),
                parse_mode='HTML',
                disable_web_page_preview=True
            )
    except Exception as e:
        logger.warning(f"Failed to send full article text: {e}")


async def crawl_and_send(context: ContextTypes.DEFAULT_TYPE):
    """Crawl feeds and send new articles dengan foto dan narasi lengkap"""
    global crawl_paused
    
    if crawl_paused:
        logger.info("Crawl is paused, skipping...")
        return
    
    logger.info("Starting crawl...")
    
    entries = fetch_feeds()
    new_count = 0
    
    for entry in entries:
        url = entry['link']
        title = entry['title']
        published = entry.get('published', '')
        
        # Skip if already sent
        if is_article_sent(url):
            continue
        
        # Filter: hanya ambil berita dalam 24 jam terakhir
        if not is_recent_article(published, hours=24):
            logger.debug(f"Skipping old article in auto crawl: {title[:50]} (published: {published})")
            continue
        
        try:
            logger.info(f"Processing article: {title}")
            
            # Fetch article image (dilakukan paralel dengan text untuk efisiensi)
            image_url = None
            try:
                image_url = fetch_article_image(url)
                if image_url:
                    logger.info(f"Found image for article: {image_url[:80]}...")
            except Exception as img_err:
                logger.warning(f"Could not fetch image: {img_err}")
            
            # Fetch article text lengkap
            article_text = fetch_article_text(url)
            if not article_text or len(article_text.strip()) < 50:
                logger.warning(f"Article text too short or empty for: {title}")
                # Skip artikel yang tidak memiliki konten cukup
                continue
            
            logger.info(f"Fetched article text: {len(article_text)} characters")
            
            # Summarize if OpenAI API key is provided
            summary = None
            if config.OPENAI_API_KEY and article_text:
                try:
                    summary = summarize_with_openai(article_text)
                    if summary:
                        logger.info("Generated OpenAI summary")
                except Exception as summary_err:
                    logger.warning(f"OpenAI summarization failed: {summary_err}")
            
            message, reply_markup = format_message(entry, article_text, summary, is_caption=False)
            
            await send_news_to_chats(context, message, None, reply_markup)
            
            # Mark as sent
            mark_article_sent(url, title)
            new_count += 1
            
            logger.info(f"✅ Sent new article: {title}")
            
            # Delay sedikit antara pengiriman untuk menghindari rate limit
            await asyncio.sleep(2)
        
        except Exception as e:
            logger.error(f"Error processing article {url}: {e}")
    
    logger.info(f"🎉 Crawl completed. Sent {new_count} new articles")


# Custom keyboard untuk menu perintah
def get_main_keyboard():
    """Membuat custom keyboard untuk menu perintah dengan design yang lebih menarik"""
    keyboard = [
        [
            KeyboardButton("🔄 Crawling Realtime"),
            KeyboardButton("📊 Status Bot")
        ],
        [
            KeyboardButton("🔄 Crawl Manual"),
            KeyboardButton("🔍 Browse Berita")
        ],
        [
            KeyboardButton("⏸️ Pause"),
            KeyboardButton("▶️ Resume")
        ],
        [
            KeyboardButton("📰 Daftar Sumber"),
            KeyboardButton("➕ Tambah Sumber")
        ],
        [
            KeyboardButton("⚙️ Pengaturan"),
            KeyboardButton("📤 Export Data")
        ],
        [
            KeyboardButton("❌ Tutup Menu")
        ]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


def get_inline_menu():
    """Membuat inline keyboard untuk menu cepat"""
    keyboard = [
        [
            InlineKeyboardButton("🔄 Crawling Realtime", callback_data="menu_latest"),
            InlineKeyboardButton("📊 Status", callback_data="menu_status")
        ],
        [
            InlineKeyboardButton("🔍 Browse Berita", callback_data="menu_browse"),
            InlineKeyboardButton("📰 Daftar Sumber", callback_data="menu_sources")
        ],
        [
            InlineKeyboardButton("⚙️ Pengaturan", callback_data="menu_settings"),
            InlineKeyboardButton("ℹ️ Bantuan", callback_data="menu_help")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)


# Command handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command dengan custom keyboard yang lebih menarik"""
    welcome_text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃     🤖 <b>MuaroNewsBot</b>     ┃\n"
        "┃   <i>Berita Terkini Muaro Jambi</i>   ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        
        "📰 <b>Bot Berita Otomatis Canggih</b>\n\n"
        "Bot untuk crawling dan mengirim berita terbaru dari Google News RSS tentang Muaro Jambi dengan tampilan yang menarik dan konten lengkap.\n\n"
        
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃  ✨ <b>FITUR UTAMA</b>  ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "📸 <b>Berita dengan Foto</b> - Setiap berita dilengkapi dengan gambar artikel\n"
        "📖 <b>Resume Lengkap</b> - Narasi artikel lengkap hingga 30 paragraf\n"
        "🔄 <b>Update Otomatis</b> - Crawl otomatis setiap 24 jam\n"
        "🤖 <b>Ringkasan AI</b> - Ringkasan artikel dengan OpenAI (opsional)\n"
        "🔍 <b>Browse Berita</b> - Telusuri berita yang sudah dikirim\n"
        "⏱️ <b>Filter Waktu</b> - Hanya berita 24 jam terakhir\n\n"
        
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃  📋 <b>DAFTAR PERINTAH</b>  ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "<b>📰 Berita:</b>\n"
        "• /latest - Crawling Realtime (ambil berita terbaru)\n"
        "• /browse - Telusuri berita yang sudah dikirim\n\n"
        
        "<b>⚙️ Kontrol Bot:</b>\n"
        "• /status - Status bot dan statistik\n"
        "• /manual_crawl - Crawl manual sekarang\n"
        "• /pause - Jeda crawl otomatis\n"
        "• /resume - Lanjutkan crawl\n\n"
        
        "<b>📰 Sumber RSS:</b>\n"
        "• /list_sources - Lihat sumber RSS\n"
        "• /add_source - Tambah sumber baru\n"
        "• /remove_source - Hapus sumber\n\n"
        
        "<b>🔧 Pengaturan:</b>\n"
        "• /set_interval - Ubah interval crawl\n"
        "• /export_db - Export database\n\n"
        
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃  💡 <b>TIPS</b>  ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "⌨️ Gunakan tombol di bawah untuk navigasi cepat\n"
        "📱 Atau ketik perintah dengan garis miring (/)\n"
        "🔄 Bot otomatis crawl setiap 24 jam\n"
        "📰 Semua berita tersimpan di database\n\n"
        
        "<i>🎯 Pilih tombol di bawah untuk mulai menggunakan bot!</i>"
    )
    
    await update.message.reply_text(
        welcome_text,
        parse_mode='HTML',
        reply_markup=get_main_keyboard()
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /status command"""
    global crawl_paused, current_job
    
    conn = get_connection()
    cursor = conn.cursor()
    
    # Count sent articles
    cursor.execute('SELECT COUNT(*) as count FROM sent_articles')
    sent_count = cursor.fetchone()['count']
    
    # Count sources
    cursor.execute('SELECT COUNT(*) as count FROM sources WHERE enabled = 1')
    sources_count = cursor.fetchone()['count']
    
    # Get latest article
    cursor.execute('SELECT title, sent_at FROM sent_articles ORDER BY sent_at DESC LIMIT 1')
    latest = cursor.fetchone()
    
    conn.close()
    
    # Calculate hours and minutes from seconds
    interval_hours = config.FETCH_INTERVAL_SECONDS // 3600
    interval_mins = (config.FETCH_INTERVAL_SECONDS % 3600) // 60
    
    status_text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃  📊 <b>STATUS BOT</b>  ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        
        "┌──────────────────────────────────┐\n"
        f"│ {'⏸️' if crawl_paused else '▶️'} <b>Status Crawl:</b> {'<b>⏸️ PAUSED</b>' if crawl_paused else '<b>✅ ACTIVE</b>'} │\n"
        "└──────────────────────────────────┘\n\n"
        
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃  📈 <b>STATISTIK</b>  ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"⏱️ <b>Interval:</b> {config.FETCH_INTERVAL_SECONDS} detik\n"
        f"   ({interval_hours} jam {interval_mins} menit)\n\n"
        f"📰 <b>Sumber Aktif:</b> <b>{sources_count}</b>\n\n"
        f"📬 <b>Artikel Terkirim:</b> <b>{sent_count}</b>\n\n"
    )
    
    if latest:
        latest_title = latest['title'][:60] + "..." if len(latest['title']) > 60 else latest['title']
        status_text += (
            "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            "┃  📌 <b>ARTIKEL TERAKHIR</b>  ┃\n"
            "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"<i>{html.escape(latest_title)}</i>\n\n"
        )
    
    status_text += (
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃  🤖 <b>FITUR AI</b>  ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"OpenAI: {'✅ <b>Aktif</b>' if config.OPENAI_API_KEY else '❌ Nonaktif'}\n\n"
        "💡 <i>Ringkasan AI akan otomatis dibuat jika API key tersedia</i>"
    )
    
    await update.message.reply_text(status_text, parse_mode='HTML', reply_markup=get_main_keyboard())


async def safe_edit_message(message, text: str, parse_mode: str = 'HTML', reply_markup=None):
    """
    Helper function untuk mengedit pesan dengan error handling.
    Jika pesan tidak bisa diedit, hapus dan kirim pesan baru.
    """
    try:
        return await message.edit_text(
            text=text,
            parse_mode=parse_mode,
            reply_markup=reply_markup
        )
    except BadRequest as e:
        if "can't be edited" in str(e).lower() or "message can't be edited" in str(e).lower():
            # Jika pesan tidak bisa diedit, hapus dan kirim pesan baru
            try:
                await message.delete()
            except Exception:
                pass
            # Kirim pesan baru
            return await message.chat.send_message(
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup
            )
        else:
            # Error lain, raise kembali
            raise


async def show_latest_news(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Crawling Realtime - Ambil dan tampilkan berita terbaru dengan crawling yang lebih baik"""
    status_msg = None
    try:
        status_msg = await update.message.reply_text(
            "╔══════════════════════════════════════╗\n"
            "║  🔄 <b>CRAWLING REALTIME</b>  ║\n"
            "╚══════════════════════════════════════╝\n\n"
            "🔄 <b>Status:</b> Memulai crawling dari semua sumber RSS...\n"
            "⏳ Mohon tunggu sebentar...",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )
        
        # Fetch feeds dengan progress update
        status_msg = await safe_edit_message(
            status_msg,
            "╔══════════════════════════════════════╗\n"
            "║  🔄 <b>CRAWLING REALTIME</b>  ║\n"
            "╚══════════════════════════════════════╝\n\n"
            "🔄 <b>Status:</b> Mengambil feed dari semua sumber RSS...\n"
            "📡 Memproses setiap sumber...\n"
            "⏳ Mohon tunggu sebentar...",
            parse_mode='HTML'
        )
        
        # Fetch feeds
        entries = fetch_feeds()
        
        if not entries:
            await safe_edit_message(
                status_msg,
                "╔══════════════════════════════════════╗\n"
                "║     ❌ <b>TIDAK ADA BERITA</b>     ║\n"
                "╚══════════════════════════════════════╝\n\n"
                "⚠️ Tidak ada berita ditemukan dari sumber RSS.\n\n"
                "💡 <b>Tips:</b>\n"
                "• Cek apakah semua sumber RSS aktif\n"
                "• Gunakan /list_sources untuk melihat daftar sumber\n"
                "• Pastikan koneksi internet stabil",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
            return
        
        # Update status
        status_msg = await safe_edit_message(
            status_msg,
            f"╔══════════════════════════════════════╗\n"
            f"║  🔄 <b>CRAWLING REALTIME</b>  ║\n"
            f"╚══════════════════════════════════════╝\n\n"
            f"✅ <b>Status:</b> Ditemukan {len(entries)} berita dari RSS\n"
            f"🔍 <b>Memfilter:</b> Berita baru (24 jam terakhir)...\n"
            f"⏳ Mohon tunggu...",
            parse_mode='HTML'
        )
        
        # Filter berita: belum dikirim DAN dalam 24 jam terakhir
        new_entries = []
        now = datetime.now(timezone.utc)
        
        for entry in entries:
            url = entry['link']
            published = entry.get('published', '')
            
            # Filter: belum dikirim dan dalam 24 jam terakhir
            if not is_article_sent(url) and is_recent_article(published, hours=24):
                new_entries.append(entry)
        
        if not new_entries:
            await safe_edit_message(
                status_msg,
                "╔══════════════════════════════════════╗\n"
                "║  ✅ <b>TIDAK ADA BERITA BARU</b>  ║\n"
                "╚══════════════════════════════════════╝\n\n"
                "📊 <b>Status:</b> Semua berita terbaru (24 jam terakhir) sudah pernah dikirim.\n\n"
                "💡 <b>Tips:</b>\n"
                "• Gunakan /browse untuk melihat berita yang sudah dikirim\n"
                "• Coba lagi nanti untuk berita terbaru\n"
                "• Atau gunakan /manual_crawl untuk crawl ulang",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
            return
        
        # Urutkan berdasarkan tanggal terbaru (RSS biasanya sudah terurut, tapi pastikan)
        new_entries.sort(key=lambda x: parse_date(x.get('published', '')) or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
        
        # Ambil SEMUA berita baru (tidak ada limit)
        latest_entries = new_entries
    
        # Update status dengan info lengkap
        status_msg = await safe_edit_message(
            status_msg,
            f"╔══════════════════════════════════════╗\n"
            f"║  🔄 <b>CRAWLING REALTIME</b>  ║\n"
            f"╚══════════════════════════════════════╝\n\n"
            f"✅ <b>Status:</b> Siap memproses berita\n\n"
            f"📊 <b>Statistik:</b>\n"
            f"• Total berita ditemukan: <b>{len(entries)}</b>\n"
            f"• Berita baru (24 jam): <b>{len(new_entries)}</b>\n"
            f"• Berita sudah dikirim: <b>{len(entries) - len(new_entries)}</b>\n\n"
            f"🔄 <b>Memproses:</b> {len(new_entries)} berita baru...\n"
            f"⏳ Mohon tunggu sebentar...",
            parse_mode='HTML'
        )
        
        # Tampilkan berita satu persatu
        sent_count = 0
        sent_articles_list = []  # Simpan daftar berita yang berhasil dikirim
        for i, entry in enumerate(latest_entries, 1):
            try:
                url = entry['link']
                title = entry['title']
                
                # Check lagi untuk memastikan belum dikirim
                if is_article_sent(url):
                    continue
                
                # Progress indicator dengan info lebih detail
                pub_date = parse_date(entry.get('published', ''))
                time_info = ""
                if pub_date:
                    time_diff = datetime.now(timezone.utc) - (pub_date if pub_date.tzinfo else pub_date.replace(tzinfo=timezone.utc))
                    hours_ago = int(time_diff.total_seconds() / 3600)
                    minutes_ago = int((time_diff.total_seconds() % 3600) / 60)
                    if hours_ago > 0:
                        time_info = f" ({hours_ago}j {minutes_ago}m lalu)"
                    else:
                        time_info = f" ({minutes_ago}m lalu)"
                
                # Progress message yang lebih informatif
                progress_msg = await update.message.reply_text(
                f"╔══════════════════════════════════════╗\n"
                f"║  📥 <b>MEMPROSES BERITA</b>  ║\n"
                f"╚══════════════════════════════════════╝\n\n"
                f"📊 <b>Progress:</b> {i}/{len(latest_entries)} berita{time_info}\n\n"
                f"📰 <b>Judul:</b> <i>{html.escape(title[:70])}{'...' if len(title) > 70 else ''}</i>\n\n"
                f"🔄 Mengambil konten artikel lengkap...\n"
                f"⏳ Mohon tunggu...",
                parse_mode='HTML'
                )
                
                # Fetch article image (prioritaskan dari CSE jika ada, lalu scrape)
                image_url = entry.get('image_url')  # Cek apakah sudah ada dari CSE
                if not image_url:
                    try:
                        image_url = fetch_article_image(url)
                        if image_url:
                            # Validasi gambar dengan mencoba download header
                            try:
                                headers = {
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                                }
                                img_response = requests.head(image_url, headers=headers, timeout=5, allow_redirects=True)
                                content_type = img_response.headers.get('content-type', '').lower()
                                
                                if 'image' not in content_type:
                                    logger.warning(f"Invalid image content-type: {content_type}")
                                    image_url = None
                                else:
                                    logger.info(f"✅ Validated image: {image_url[:80]}")
                            except Exception as validate_err:
                                logger.warning(f"Image validation failed: {validate_err}, will try anyway")
                    except Exception as img_err:
                        logger.warning(f"Could not fetch image: {img_err}")
                else:
                    logger.info(f"✅ Using image from CSE: {image_url[:80]}...")
                
                # Fetch article text (tetap kirim meskipun tidak lengkap)
                article_text = ""
                try:
                    article_text = fetch_article_text(url)
                    logger.info(f"Fetched article text: {len(article_text)} chars for {title[:50]}")
                except Exception as text_err:
                    logger.warning(f"Could not fetch article text: {text_err}")
                    # Gunakan summary dari RSS sebagai fallback
                    article_text = entry.get('summary', '') or entry.get('description', '')
                
                # Jika article text masih kosong atau terlalu pendek, gunakan summary dari RSS
                if not article_text or len(article_text.strip()) < 30:
                    article_text = entry.get('summary', '') or entry.get('description', '') or title
                    logger.info(f"Using RSS summary/description for {title[:50]}")
                
                # Summarize if OpenAI available (hanya jika article_text cukup panjang)
                summary = None
                if config.OPENAI_API_KEY and article_text and len(article_text.strip()) > 100:
                    try:
                        summary = summarize_with_openai(article_text)
                        logger.info(f"Generated OpenAI summary for {title[:50]}")
                    except Exception as summary_err:
                        logger.warning(f"OpenAI summary failed: {summary_err}")
                
                # Format and send message (PASTI kirim, tidak ada skip lagi)
                try:
                    chat_id = update.effective_chat.id
                    sent = False
                    
                    message, reply_markup = format_message(entry, article_text, summary, is_caption=False)
                    try:
                        await context.bot.send_message(
                            chat_id=chat_id,
                            text=message,
                            parse_mode='HTML',
                            disable_web_page_preview=False,
                            reply_markup=reply_markup
                        )
                        sent = True
                        logger.info(f"✅ Sent single-card news to {chat_id}: {title[:50]}")
                    except Exception as msg_err:
                        logger.error(f"Failed to send message: {msg_err}")
                    
                    if sent:
                        mark_article_sent(url, title)
                        sent_count += 1
                        # Simpan info berita yang dikirim untuk summary
                        sent_articles_list.append({
                            'title': title,
                            'url': url,
                            'has_image': bool(image_url),
                            'source': entry.get('source', {}).get('title', 'Sumber Tidak Dikenal')
                        })
                    else:
                        logger.error(f"Failed to send article to {chat_id}: {title}")
                        
                except Exception as format_err:
                    logger.error(f"Error formatting/sending message: {format_err}")
                    # Tetap coba kirim dengan format minimal
                    try:
                        simple_msg = (
                            f"📰 <b>{html.escape(title)}</b>\n\n"
                            f"📅 {entry.get('published', '')}\n"
                            f"📡 {entry.get('source', {}).get('title', 'Sumber')}\n\n"
                            f"🔗 <a href='{url}'>Baca selengkapnya</a>"
                        )
                        await context.bot.send_message(
                            chat_id=update.effective_chat.id,
                            text=simple_msg,
                            parse_mode='HTML'
                        )
                        mark_article_sent(url, title)
                        sent_count += 1
                        sent_articles_list.append({
                            'title': title,
                            'url': url,
                            'has_image': False,
                            'source': entry.get('source', {}).get('title', 'Sumber Tidak Dikenal')
                        })
                        logger.info(f"✅ Sent simple format to {update.effective_chat.id}: {title[:50]}")
                    except Exception as simple_err:
                        logger.error(f"Failed to send even simple format: {simple_err}")
                
                # Delete progress message
                try:
                    await progress_msg.delete()
                except Exception:
                    pass
                
                # Delay antar pengiriman
                await asyncio.sleep(1)
            
            except Exception as e:
                logger.error(f"Error showing latest news: {e}")
                try:
                    await progress_msg.delete()
                except Exception:
                    pass
                # Kirim pesan error yang informatif
                try:
                    await update.message.reply_text(
                        f"╔══════════════════════════════════════╗\n"
                        f"║  ❌ <b>ERROR MEMPROSES BERITA</b>  ║\n"
                        f"╚══════════════════════════════════════╝\n\n"
                        f"⚠️ Terjadi error saat memproses berita:\n\n"
                        f"<code>{html.escape(str(e))}</code>\n\n"
                        f"💡 <b>Tips:</b>\n"
                        f"• Coba lagi dengan <code>/latest</code> (Crawling Realtime)\n"
                        f"• Cek koneksi internet\n"
                        f"• Gunakan <code>/status</code> untuk cek status bot",
                        parse_mode='HTML',
                        reply_markup=get_main_keyboard()
                    )
                except Exception:
                    pass
        
        # Summary lengkap dengan daftar berita yang dikirim (format lebih rapih)
        if sent_count > 0:
            # Hitung statistik
            with_image = sum(1 for a in sent_articles_list if a['has_image'])
            text_only = sum(1 for a in sent_articles_list if not a['has_image'])
            
            summary_text = (
            "╔══════════════════════════════════════╗\n"
            "║  ✅ <b>CRAWL SELESAI!</b>  ║\n"
            "╚══════════════════════════════════════╝\n\n"
            "╔══════════════════════════════════════╗\n"
            "║  📊 <b>RINGKASAN CRAWL</b>  ║\n"
            "╚══════════════════════════════════════╝\n\n"
            f"📰 <b>Total berita dikirim:</b> <b>{sent_count}</b>\n"
            f"📸 <b>Dengan foto:</b> <b>{with_image}</b>\n"
            f"📄 <b>Teks saja:</b> <b>{text_only}</b>\n"
            f"⏱️ <b>Filter waktu:</b> 24 jam terakhir\n"
            f"📊 <b>Success rate:</b> {sent_count}/{len(latest_entries)} ({int(sent_count/len(latest_entries)*100) if len(latest_entries) > 0 else 0}%)\n\n"
            "╔══════════════════════════════════════╗\n"
            "║  📋 <b>DAFTAR BERITA</b>  ║\n"
            "╚══════════════════════════════════════╝\n\n"
            )
            
            # Tampilkan daftar berita dengan format lebih rapih (maksimal 10 untuk summary)
            max_list = min(10, len(sent_articles_list))
            for idx, article in enumerate(sent_articles_list[:max_list], 1):
                img_icon = "📸" if article['has_image'] else "📄"
                title_short = html.escape(article['title'][:55] + "..." if len(article['title']) > 55 else article['title'])
                source_short = html.escape(article['source'][:30] + "..." if len(article['source']) > 30 else article['source'])
                summary_text += f"{idx:2d}. {img_icon} <b>{title_short}</b>\n"
                summary_text += f"     📡 {source_short}\n\n"
            
            # Jika ada lebih dari 10, tambahkan info
            if len(sent_articles_list) > max_list:
                remaining = len(sent_articles_list) - max_list
                summary_text += f"    ... dan <b>{remaining}</b> berita lainnya\n\n"
            
            summary_text += (
                "╔══════════════════════════════════════╗\n"
                "║  💡 <b>PERINTAH</b>  ║\n"
                "╚══════════════════════════════════════╝\n\n"
                "• <code>/latest</code> - Crawling Realtime lagi\n"
                "• <code>/browse</code> - Telusuri berita yang sudah dikirim\n"
                "• <code>/manual_crawl</code> - Crawl manual sekarang\n"
                "• Scroll ke atas untuk melihat detail setiap berita\n\n"
                "✨ <i>Semua berita sudah tersimpan di database</i>"
            )
        else:
            summary_text = (
                "╔══════════════════════════════════════╗\n"
                "║  ⚠️ <b>TIDAK ADA BERITA</b>  ║\n"
                "╚══════════════════════════════════════╝\n\n"
                "Mungkin berita sudah pernah dikirim sebelumnya atau konten artikel tidak cukup.\n\n"
                "💡 <b>Tips:</b>\n"
                "• Coba lagi nanti atau gunakan <code>/latest</code> untuk Crawling Realtime\n"
                "• Gunakan <code>/browse</code> untuk melihat berita yang sudah dikirim\n"
                "• Cek <code>/status</code> untuk melihat statistik bot"
            )
        
        if status_msg:
            try:
                await status_msg.delete()
            except Exception:
                pass
        
        await update.message.reply_text(
            summary_text,
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Error in show_latest_news: {e}", exc_info=True)
        try:
            if status_msg:
                await status_msg.delete()
        except Exception:
            pass
        await update.message.reply_text(
            f"╔══════════════════════════════════════╗\n"
            f"║  ❌ <b>ERROR</b>  ║\n"
            f"╚══════════════════════════════════════╝\n\n"
            f"⚠️ Terjadi error saat mengambil berita terbaru:\n\n"
            f"<code>{html.escape(str(e))}</code>\n\n"
            f"💡 <b>Tips:</b>\n"
            f"• Coba lagi dengan <code>/latest</code> (Crawling Realtime)\n"
            f"• Cek koneksi internet dan database\n"
            f"• Gunakan <code>/status</code> untuk cek status bot",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )


async def manual_crawl(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /manual_crawl command"""
    await update.message.reply_text("🔄 Memulai crawl manual...", reply_markup=get_main_keyboard())
    await crawl_and_send(context)
    await update.message.reply_text("✅ Crawl manual selesai!", reply_markup=get_main_keyboard())


async def pause(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /pause command"""
    global crawl_paused
    crawl_paused = True
    await update.message.reply_text(
        "⏸️ <b>Crawl di-pause</b>\n\nGunakan /resume atau tombol ▶️ Resume untuk melanjutkan.",
        parse_mode='HTML',
        reply_markup=get_main_keyboard()
    )


async def resume(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /resume command"""
    global crawl_paused
    crawl_paused = False
    await update.message.reply_text(
        "▶️ <b>Crawl di-resume</b>\n\nBot akan melanjutkan crawl otomatis sesuai interval yang ditentukan.",
        parse_mode='HTML',
        reply_markup=get_main_keyboard()
    )


async def list_sources(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /list_sources command"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, name, url, enabled FROM sources')
    sources = cursor.fetchall()
    conn.close()
    
    if not sources:
        await update.message.reply_text("📋 Tidak ada sumber RSS yang terdaftar.")
        return
    
    text = "📋 <b>Daftar Sumber RSS</b>\n\n━━━━━━━━━━━━━━━━━━━━\n\n"
    for source in sources:
        source_id = source['id']
        name = source['name']
        url = source['url']
        enabled = source['enabled']
        status_icon = "✅" if enabled else "❌"
        text += f"{status_icon} <b>ID {source_id}:</b> {name}\n"
        text += f"   <code>{url[:60]}...</code>\n\n"
    text += "━━━━━━━━━━━━━━━━━━━━"
    
    await update.message.reply_text(text, parse_mode='HTML', reply_markup=get_main_keyboard())


async def add_source(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /add_source command"""
    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "❌ Format: /add_source <nama> <url>\n"
            "Contoh: /add_source \"Berita Lokal\" https://example.com/rss"
        )
        return
    
    name = context.args[0]
    url = ' '.join(context.args[1:])
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO sources (name, url) VALUES (%s, %s)',
            (name, url)
        )
        conn.commit()
        conn.close()
        
        await update.message.reply_text(f"✅ Sumber RSS ditambahkan: {name}")
    
    except pymysql.IntegrityError:
        await update.message.reply_text("❌ Sumber RSS dengan URL tersebut sudah ada.")
    except Exception as e:
        logger.error(f"Error adding source: {e}")
        await update.message.reply_text(f"❌ Error: {e}")


async def remove_source(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /remove_source command"""
    if not context.args or len(context.args) < 1:
        await update.message.reply_text("❌ Format: /remove_source <id>\nGunakan /list_sources untuk melihat ID")
        return
    
    try:
        source_id = int(context.args[0])
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM sources WHERE id = %s', (source_id,))
        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        
        if deleted:
            await update.message.reply_text(f"✅ Sumber RSS ID {source_id} dihapus.")
        else:
            await update.message.reply_text(f"❌ Sumber RSS ID {source_id} tidak ditemukan.")
    
    except ValueError:
        await update.message.reply_text("❌ ID harus berupa angka.")
    except Exception as e:
        logger.error(f"Error removing source: {e}")
        await update.message.reply_text(f"❌ Error: {e}")


async def set_interval(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /set_interval command"""
    global current_job
    
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "❌ Format: /set_interval <detik>\n"
            "Contoh: /set_interval 600 (untuk 10 menit)"
        )
        return
    
    try:
        new_interval = int(context.args[0])
        if new_interval < 60:
            await update.message.reply_text("❌ Interval minimal 60 detik (1 menit)")
            return
        
        # Update config
        config.FETCH_INTERVAL_SECONDS = new_interval
        
        # Reschedule job if exists
        if current_job:
            current_job.schedule_removal()
        
        # Add new job
        job_queue = context.application.job_queue
        current_job = job_queue.run_repeating(
            crawl_and_send,
            interval=new_interval,
            first=10
        )
        
        await update.message.reply_text(
            f"✅ Interval diubah menjadi {new_interval} detik ({new_interval // 60} menit)"
        )
    
    except ValueError:
        await update.message.reply_text("❌ Interval harus berupa angka.")
    except Exception as e:
        logger.error(f"Error setting interval: {e}")
        await update.message.reply_text(f"❌ Error: {e}")


async def export_db(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /export_db command"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Get sent articles
        cursor.execute('SELECT url, title, sent_at FROM sent_articles')
        articles = cursor.fetchall()
        
        # Get sources
        cursor.execute('SELECT id, name, url, enabled FROM sources')
        sources = cursor.fetchall()
        
        conn.close()
        
        data = {
            'articles': [
                {
                    'url': article['url'],
                    'title': article['title'],
                    'sent_at': article['sent_at'].isoformat() if article['sent_at'] else None
                }
                for article in articles
            ],
            'sources': [
                {
                    'id': source['id'],
                    'name': source['name'],
                    'url': source['url'],
                    'enabled': bool(source['enabled'])
                }
                for source in sources
            ],
            'exported_at': datetime.now().isoformat()
        }
        
        json_str = json.dumps(data, indent=2, ensure_ascii=False)
        
        # Send as document if too long, otherwise as text
        if len(json_str) > 4096:
            # Save to file and send as document
            filename = f"muaronewsbot_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(json_str)
            
            with open(filename, 'rb') as f:
                await update.message.reply_document(
                    document=f,
                    filename=filename
                )
            
            # Delete temp file
            try:
                os.remove(filename)
            except Exception:
                pass
        else:
            await update.message.reply_text(f"<pre>{html.escape(json_str)}</pre>", parse_mode='HTML', reply_markup=get_main_keyboard())
    
    except Exception as e:
        logger.error(f"Error exporting database: {e}")
        await update.message.reply_text(f"❌ Error: {e}", reply_markup=get_main_keyboard())


async def browse_news(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Telusuri berita yang sudah dikirim dari database"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Ambil parameter limit (default 10, max 20)
        limit = 10
        if context.args and len(context.args) > 0:
            try:
                limit = min(20, max(1, int(context.args[0])))
            except ValueError:
                pass
        
        # Query berita terbaru dari database
        cursor.execute('''
            SELECT url, title, sent_at 
            FROM sent_articles 
            ORDER BY sent_at DESC 
            LIMIT %s
        ''', (limit,))
        articles = cursor.fetchall()
        conn.close()
        
        if not articles:
            await update.message.reply_text(
                "📭 <b>Belum ada berita yang dikirim</b>\n\n"
                "Database masih kosong. Gunakan /latest untuk Crawling Realtime.",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
            return
        
        # Format daftar berita dengan tampilan rapih
        browse_text = (
            f"🔍 <b>BROWSE BERITA TERKIRIM</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"📊 Menampilkan <b>{len(articles)}</b> berita terbaru:\n\n"
        )
        
        for idx, article in enumerate(articles, 1):
            title = html.escape(article['title'][:65] + "..." if len(article['title']) > 65 else article['title'])
            url = article['url']
            sent_at = article['sent_at']
            
            # Format waktu
            if sent_at:
                if isinstance(sent_at, str):
                    sent_at = parse_date(sent_at)
                if sent_at:
                    now = datetime.now(timezone.utc)
                    if sent_at.tzinfo is None:
                        sent_at = sent_at.replace(tzinfo=timezone.utc)
                    
                    time_diff = now - sent_at
                    days_ago = time_diff.days
                    hours_ago = int((time_diff.total_seconds() % 86400) / 3600)
                    
                    if days_ago > 0:
                        time_str = f"{days_ago} hari lalu"
                    elif hours_ago > 0:
                        time_str = f"{hours_ago} jam lalu"
                    else:
                        minutes_ago = int((time_diff.total_seconds() % 3600) / 60)
                        time_str = f"{minutes_ago} menit lalu"
                else:
                    time_str = "Waktu tidak diketahui"
            else:
                time_str = "Waktu tidak diketahui"
            
            browse_text += (
                f"{idx:2d}. <b>{title}</b>\n"
                f"     🕐 {time_str}\n"
                f"     🔗 <b><a href='{url}'>Baca Artikel Lengkap</a></b>\n"
                f"     🌐 <code>{url[:55]}{'...' if len(url) > 55 else ''}</code>\n\n"
            )
        
        browse_text += (
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "💡 <b>Tips:</b>\n"
            f"• Gunakan <code>/browse {limit + 10}</code> untuk melihat lebih banyak\n"
            "• Maksimal 20 berita per query\n"
            "• Link artikel dapat diklik langsung"
        )
        
        await update.message.reply_text(
            browse_text,
            parse_mode='HTML',
            reply_markup=get_main_keyboard(),
            disable_web_page_preview=True
        )
    
    except Exception as e:
        logger.error(f"Error browsing news: {e}")
        await update.message.reply_text(
            f"❌ <b>Error browsing berita:</b>\n\n<code>{html.escape(str(e))}</code>",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )


def main():
    """Main function to start the bot"""
    global current_job
    
    # Initialize database
    init_database()
    
    # Check configuration
    if not config.BOT_TOKEN:
        logger.error("BOT_TOKEN tidak diisi di config.py!")
        return
    
    if not config.TARGET_CHAT_IDS:
        logger.warning("TARGET_CHAT_IDS kosong di config.py! Bot tidak akan mengirim pesan ke siapa pun.")
    
    # Test database connection
    try:
        test_conn = get_connection()
        test_conn.close()
        logger.info("MySQL database connection successful")
    except Exception as e:
        logger.error(f"MySQL database connection failed: {e}")
        logger.error("Pastikan MySQL sudah berjalan dan konfigurasi di config.py benar!")
        return
    
    # Create application dengan timeout yang lebih panjang
    try:
        application = (
            Application.builder()
            .token(config.BOT_TOKEN)
            .connect_timeout(config.TELEGRAM_CONNECT_TIMEOUT)
            .read_timeout(config.TELEGRAM_READ_TIMEOUT)
            .write_timeout(config.TELEGRAM_WRITE_TIMEOUT)
            .pool_timeout(config.TELEGRAM_POOL_TIMEOUT)
            .build()
        )
        logger.info(f"Application created with timeouts: connect={config.TELEGRAM_CONNECT_TIMEOUT}s, read={config.TELEGRAM_READ_TIMEOUT}s")
    except Exception as e:
        logger.error(f"Failed to create application: {e}")
        return
    
    # Handler untuk keyboard button
    async def handle_keyboard_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle keyboard button presses"""
        text = update.message.text
        
        # Handle tombol keyboard yang baru
        if text == "🔄 Crawling Realtime":
            await show_latest_news(update, context)
        elif text == "📊 Status Bot":
            await status(update, context)
        elif text == "🔄 Crawl Manual":
            await manual_crawl(update, context)
        elif text == "🔍 Browse Berita":
            await browse_news(update, context)
        elif text == "⏸️ Pause":
            await pause(update, context)
        elif text == "▶️ Resume":
            await resume(update, context)
        elif text == "📰 Daftar Sumber":
            await list_sources(update, context)
        elif text == "➕ Tambah Sumber":
            await update.message.reply_text(
                "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
                "┃  ➕ <b>TAMBAH SUMBER RSS</b>  ┃\n"
                "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
                "📝 <b>Format:</b>\n"
                "<code>/add_source \"Nama Sumber\" https://example.com/rss</code>\n\n"
                "📋 <b>Contoh:</b>\n"
                "<code>/add_source \"Berita Lokal\" https://example.com/rss</code>\n\n"
                "💡 <i>Gunakan tanda kutip untuk nama yang mengandung spasi</i>",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
        elif text == "⚙️ Pengaturan":
            await update.message.reply_text(
                "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
                "┃  ⚙️ <b>PENGATURAN BOT</b>  ┃\n"
                "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
                "📋 <b>Daftar Pengaturan:</b>\n\n"
                "⏱️ <b>Interval Crawl:</b>\n"
                "• /set_interval <detik>\n"
                "• Contoh: <code>/set_interval 86400</code> (24 jam)\n\n"
                "📰 <b>Kelola Sumber:</b>\n"
                "• /list_sources - Lihat semua sumber\n"
                "• /add_source - Tambah sumber baru\n"
                "• /remove_source - Hapus sumber\n\n"
                "📤 <b>Data:</b>\n"
                "• /export_db - Export database\n\n"
                "💡 <i>Pilih menu di bawah untuk navigasi cepat</i>",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
        elif text == "📤 Export Data":
            await export_db(update, context)
        elif text == "❌ Tutup Menu":
            await update.message.reply_text(
                "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
                "┃  ✅ <b>MENU DITUTUP</b>  ┃\n"
                "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
                "⌨️ Menu keyboard telah dihapus.\n\n"
                "💡 Ketik <code>/start</code> untuk menampilkan menu lagi.",
                parse_mode='HTML',
                reply_markup=ReplyKeyboardRemove()
            )
    
    # Register keyboard button handler (harus sebelum command handler)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_keyboard_button))
    
    # Register command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("status", status))
    application.add_handler(CommandHandler("latest", show_latest_news))
    application.add_handler(CommandHandler("manual_crawl", manual_crawl))
    application.add_handler(CommandHandler("pause", pause))
    application.add_handler(CommandHandler("resume", resume))
    application.add_handler(CommandHandler("list_sources", list_sources))
    application.add_handler(CommandHandler("add_source", add_source))
    application.add_handler(CommandHandler("remove_source", remove_source))
    application.add_handler(CommandHandler("set_interval", set_interval))
    application.add_handler(CommandHandler("export_db", export_db))
    application.add_handler(CommandHandler("browse", browse_news))
    
    # Schedule periodic crawl
    job_queue = application.job_queue
    if job_queue is None:
        logger.error("JobQueue tidak tersedia! Install dengan: pip install \"python-telegram-bot[job-queue]\"")
        return
    
    # Schedule periodic crawl (default: 24 jam sekali)
    # First crawl akan dilakukan setelah interval pertama, bukan langsung saat start
    current_job = job_queue.run_repeating(
        crawl_and_send,
        interval=config.FETCH_INTERVAL_SECONDS,
        first=config.FETCH_INTERVAL_SECONDS  # Start first crawl setelah interval pertama (tidak langsung)
    )
    
    logger.info("Bot started")
    logger.info(f"Crawl interval: {config.FETCH_INTERVAL_SECONDS} seconds")
    
    # Start bot
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
