-- --- FILE: database.sql ---
-- MuaroNewsBot Database Schema
-- Copy paste script ini ke phpMyAdmin > SQL tab

-- Buat database (jika belum ada)
CREATE DATABASE IF NOT EXISTS `muaronewsbot` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- Gunakan database
USE `muaronewsbot`;

-- Table untuk menyimpan URL artikel yang sudah dikirim
CREATE TABLE IF NOT EXISTS `sent_articles` (
  `url` VARCHAR(500) NOT NULL PRIMARY KEY,
  `title` TEXT NULL,
  `sent_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table untuk menyimpan sumber RSS
CREATE TABLE IF NOT EXISTS `sources` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `url` VARCHAR(500) NOT NULL UNIQUE,
  `enabled` TINYINT NOT NULL DEFAULT 1,
  INDEX `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default sources (Google News - Muaro Jambi - multiple queries untuk hasil lebih banyak)
INSERT IGNORE INTO `sources` (`name`, `url`, `enabled`)
VALUES 
(
  'Google News - Muaro Jambi',
  'https://news.google.com/rss/search?q=Muaro+Jambi&hl=id&gl=ID&ceid=ID:id',
  1
),
(
  'Google News - Muaro Jambi (Berita Terkini)',
  'https://news.google.com/rss/search?q=Muaro+Jambi+berita&hl=id&gl=ID&ceid=ID:id&when:24h',
  1
),
(
  'Google News - Muaro Jambi (Kota)',
  'https://news.google.com/rss/search?q=%22Muaro+Jambi%22+kota&hl=id&gl=ID&ceid=ID:id&when:24h',
  1
),
(
  'Google News - Muaro Jambi (Kabupaten)',
  'https://news.google.com/rss/search?q=%22Muaro+Jambi%22+kabupaten&hl=id&gl=ID&ceid=ID:id&when:24h',
  1
),
(
  'Google News - Muaro Jambi (Pemerintahan)',
  'https://news.google.com/rss/search?q=Muaro+Jambi+pemerintah&hl=id&gl=ID&ceid=ID:id&when:24h',
  1
);

