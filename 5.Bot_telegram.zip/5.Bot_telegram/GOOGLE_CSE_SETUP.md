# Setup Google Custom Search Engine (CSE) untuk Bot

## Cara Setup Google CSE

### 1. Buat API Key di Google Cloud Console
1. Buka: https://console.cloud.google.com/
2. Buat project baru atau pilih project yang sudah ada
3. Buka menu **APIs & Services** > **Credentials**
4. Klik **Create Credentials** > **API Key**
5. Copy API Key yang dibuat
6. (Opsional) Klik **Restrict Key** untuk membatasi penggunaan

### 2. Enable Custom Search API
1. Buka: https://console.cloud.google.com/apis/library
2. Cari "Custom Search API"
3. Klik **Enable**

### 3. Buat Custom Search Engine
1. Buka: https://programmablesearchengine.google.com/
2. Klik **Add** untuk membuat search engine baru
3. Isi:
   - **Sites to search**: Pilih "Search the entire web" (untuk berita umum)
   - **Name**: Nama search engine (contoh: "Muaro Jambi News")
   - **Language**: Indonesian
4. Klik **Create**
5. Setelah dibuat, klik **Control Panel**
6. Copy **Search Engine ID** (CX) - format: `xxxxxxxxxxxxxxxxxxxxxxxxx:xxxxxxxxxx`

### 4. Konfigurasi di Bot
Edit file `config.py`:

```python
# Google Custom Search Engine (CSE) Configuration
GOOGLE_CSE_API_KEY = "YOUR_API_KEY_HERE"  # Paste API Key dari langkah 1
GOOGLE_CSE_ENGINE_ID = "YOUR_CX_HERE"     # Paste Search Engine ID dari langkah 3
GOOGLE_CSE_ENABLED = True                 # Set True untuk mengaktifkan
```

### 5. Fitur Google CSE
✅ **Link berita langsung** - Tidak perlu extract dari redirect URL  
✅ **Gambar langsung** - Ambil gambar dari metadata artikel (og:image, twitter:image)  
✅ **Filter 24 jam** - Hanya ambil berita terbaru 24 jam  
✅ **Bahasa Indonesia** - Filter untuk berita Indonesia  
✅ **100 request/hari gratis** - Cukup untuk bot kecil-menengah  

### 6. Limit & Quota
- **Free tier**: 100 request/hari
- **Max hasil per request**: 10 artikel
- **Total maksimal**: ~50 artikel per hari (dari 5 query berbeda)

### 7. Catatan Penting
⚠️ Jika quota habis, bot akan otomatis fallback ke RSS Feed  
⚠️ Google CSE akan mengambil gambar dari metadata artikel (jika tersedia)  
⚠️ Jika gambar tidak ditemukan, bot akan tetap scrape dari website artikel  

## Testing
Setelah setup, jalankan bot dan gunakan command `/latest` untuk test apakah Google CSE berfungsi.

Log akan menampilkan:
```
✅ Google CSE: Fetched X results for query 'Muaro Jambi'
✅ Google CSE: Added X new entries
```

