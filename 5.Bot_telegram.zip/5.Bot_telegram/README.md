# --- FILE: README.md ---
# MuaroNewsBot

Telegram Bot untuk otomatis crawling dan mengirim berita dari Google News RSS dengan query "Muaro Jambi".

## Fitur

- ✅ Otomatis crawling berita dari Google News RSS
- ✅ Deduplikasi artikel via MySQL (menyimpan URL yang sudah dikirim)
- ✅ Job scheduler untuk crawl setiap 24 jam sekali (dapat diubah)
- ✅ Mengirim berita langsung ke Telegram dengan foto artikel
- ✅ Narasi artikel lengkap (beberapa paragraf pertama)
- ✅ Ekstraksi gambar artikel otomatis dari berbagai sumber (og:image, twitter:image, dll)
- ✅ Ringkasan artikel opsional via OpenAI (jika API key diisi)
- ✅ Format pesan yang menarik dengan HTML formatting
- ✅ Perintah Telegram lengkap untuk kontrol bot
- ✅ Logging detail untuk monitoring

## Instalasi

### 1. Persiapan Environment

```bash
# Buat virtual environment
python -m venv venv

# Aktifkan virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Setup MySQL Database

**Cara 1: Menggunakan file SQL (Recommended)**

1. Buka phpMyAdmin
2. Pilih tab **SQL**
3. Copy paste seluruh isi file `database.sql` ke textarea
4. Klik **Go** atau **Kirim**

File `database.sql` sudah berisi:
- CREATE DATABASE statement
- CREATE TABLE untuk `sent_articles` dan `sources`
- INSERT default source (Google News - Muaro Jambi)

**Cara 2: Manual**

Buat database MySQL secara manual:

```sql
CREATE DATABASE muaronewsbot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Kemudian jalankan script di `database.sql` untuk membuat tabel-tabelnya.

### 3. Konfigurasi

Edit file `config.py` dan isi:

1. **BOT_TOKEN** - Sudah diisi (token dari @BotFather)
2. **TARGET_CHAT_IDS** - Tambahkan Chat ID tujuan
   - Untuk mendapatkan Chat ID: kirim pesan ke bot, lalu cek di:
     `https://api.telegram.org/bot<TOKEN>/getUpdates`
   - Contoh: `TARGET_CHAT_IDS = [123456789, 987654321]`
3. **DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME** - Konfigurasi MySQL
   - Isi dengan kredensial MySQL Anda
   - Pastikan user memiliki akses ke database `muaronewsbot`
4. **OPENAI_API_KEY** (opsional) - Jika ingin menggunakan fitur ringkasan artikel
   - Biarkan kosong jika tidak ingin menggunakan OpenAI

### 4. Menjalankan Bot

```bash
python news_bot.py
```

Bot akan mulai berjalan dan melakukan crawl pertama setelah 10 detik, kemudian setiap 15 menit (atau sesuai interval yang diatur).

## Perintah Telegram

- `/start` - Menampilkan menu bantuan
- `/status` - Status bot dan informasi crawl
- `/manual_crawl` - Jalankan crawl manual sekarang
- `/pause` - Jeda crawl otomatis
- `/resume` - Lanjutkan crawl otomatis
- `/list_sources` - Daftar semua sumber RSS
- `/add_source <nama> <url>` - Tambah sumber RSS baru
- `/remove_source <id>` - Hapus sumber RSS berdasarkan ID
- `/set_interval <detik>` - Ubah interval crawl (minimal 60 detik)
- `/export_db` - Export database sebagai JSON

## Deploy ke VPS (Linux)

### Menggunakan systemd (Service)

1. Buat file unit systemd di `/etc/systemd/system/muaronewsbot.service`:

```ini
[Unit]
Description=MuaroNewsBot Telegram Bot
After=network.target

[Service]
Type=simple
User=your_username
WorkingDirectory=/path/to/muaronewsbot
Environment="PATH=/path/to/venv/bin"
ExecStart=/path/to/venv/bin/python /path/to/muaronewsbot/news_bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

2. Reload systemd dan start service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable muaronewsbot
sudo systemctl start muaronewsbot
```

3. Cek status:

```bash
sudo systemctl status muaronewsbot
sudo journalctl -u muaronewsbot -f  # Lihat log
```

### Menggunakan Screen/Tmux (Alternatif)

```bash
# Install screen jika belum ada
sudo apt install screen

# Buat session baru
screen -S muaronewsbot

# Aktifkan venv dan jalankan bot
cd /path/to/muaronewsbot
source venv/bin/activate
python news_bot.py

# Detach: Ctrl+A lalu D
# Reattach: screen -r muaronewsbot
```

### Menggunakan nohup (Alternatif)

```bash
cd /path/to/muaronewsbot
source venv/bin/activate
nohup python news_bot.py > bot.log 2>&1 &
```

## Struktur File

```
muaronewsbot/
├── config.py          # File konfigurasi
├── news_bot.py        # Kode utama bot
├── requirements.txt   # Dependencies Python
├── database.sql       # Script SQL untuk setup database
└── README.md          # Dokumentasi
```

## Catatan Penting

- Pastikan MySQL sudah berjalan sebelum menjalankan bot
- Pastikan `TARGET_CHAT_IDS` sudah diisi sebelum menjalankan bot
- Pastikan konfigurasi MySQL di `config.py` sudah benar
- Bot akan membuat tabel secara otomatis saat pertama kali dijalankan
- Fitur ringkasan OpenAI hanya aktif jika `OPENAI_API_KEY` diisi di `config.py`
- Ringkasan dibatasi maksimal 300 token untuk efisiensi
- Semua judul dan ringkasan di-escape untuk HTML sebelum dikirim ke Telegram

## Troubleshooting

**Bot tidak mengirim pesan:**
- Pastikan `TARGET_CHAT_IDS` sudah diisi dengan benar
- Pastikan bot sudah di-add ke chat/group dan memiliki izin mengirim pesan

**Error saat crawl:**
- Cek koneksi internet
- Cek log untuk detail error
- Pastikan URL RSS source valid

**Database error:**
- Pastikan MySQL server sudah berjalan
- Pastikan kredensial MySQL di `config.py` benar
- Pastikan database `muaronewsbot` sudah dibuat
- Pastikan user MySQL memiliki akses CREATE, INSERT, UPDATE, DELETE, SELECT pada database
- Cek log untuk detail error koneksi database

## Lisensi

Free to use and modify.

