"""
Script untuk test koneksi Google Custom Search Engine API
"""
import requests
import config

def test_google_cse():
    """Test koneksi ke Google CSE API"""
    if not config.GOOGLE_CSE_ENABLED:
        print("[X] Google CSE belum diaktifkan (GOOGLE_CSE_ENABLED = False)")
        return False
    
    if not config.GOOGLE_CSE_API_KEY:
        print("[X] GOOGLE_CSE_API_KEY belum diisi")
        return False
    
    if not config.GOOGLE_CSE_ENGINE_ID:
        print("[X] GOOGLE_CSE_ENGINE_ID belum diisi")
        return False
    
    print("[*] Testing Google CSE API...")
    print(f"    API Key: {config.GOOGLE_CSE_API_KEY[:20]}...")
    print(f"    Engine ID: {config.GOOGLE_CSE_ENGINE_ID}")
    print()
    
    try:
        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            'key': config.GOOGLE_CSE_API_KEY,
            'cx': config.GOOGLE_CSE_ENGINE_ID,
            'q': 'Muaro Jambi news',
            'num': 3,  # Test dengan 3 hasil saja
            'dateRestrict': 'd1',  # 24 jam terakhir
            'lr': 'lang_id',
            'gl': 'id',
            'safe': 'active'
        }
        
        print("[*] Mengirim request ke Google CSE API...")
        response = requests.get(url, params=params, timeout=30)
        
        print(f"    Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            items = data.get('items', [])
            
            print(f"[OK] Koneksi berhasil!")
            print(f"[*] Ditemukan {len(items)} hasil")
            print()
            
            if items:
                print("[*] Contoh hasil:")
                for i, item in enumerate(items[:3], 1):
                    print(f"\n    {i}. {item.get('title', 'No title')}")
                    print(f"       Link: {item.get('link', 'No link')}")
                    print(f"       Sumber: {item.get('displayLink', 'No source')}")
                    
                    # Cek gambar
                    pagemap = item.get('pagemap', {})
                    image_url = None
                    if 'metatags' in pagemap and pagemap['metatags']:
                        meta = pagemap['metatags'][0]
                        image_url = meta.get('og:image') or meta.get('twitter:image')
                    
                    if image_url:
                        print(f"       [IMG] Gambar: {image_url[:60]}...")
                    else:
                        print(f"       [IMG] Gambar: Tidak ditemukan")
            
            # Cek quota
            search_info = data.get('searchInformation', {})
            if search_info:
                print(f"\n[*] Search Info:")
                print(f"    Total results: {search_info.get('totalResults', 'N/A')}")
                print(f"    Search time: {search_info.get('searchTime', 'N/A')} detik")
            
            return True
            
        elif response.status_code == 400:
            error_data = response.json()
            error_msg = error_data.get('error', {}).get('message', 'Unknown error')
            print(f"[X] Error 400: {error_msg}")
            print("\n[*] Kemungkinan masalah:")
            print("    - API Key tidak valid")
            print("    - Search Engine ID (CX) tidak valid")
            print("    - Custom Search API belum di-enable di Google Cloud Console")
            return False
            
        elif response.status_code == 403:
            error_data = response.json()
            error_msg = error_data.get('error', {}).get('message', 'Unknown error')
            print(f"[X] Error 403: {error_msg}")
            print("\n[*] Kemungkinan masalah:")
            print("    - API Key tidak memiliki permission untuk Custom Search API")
            print("    - Quota sudah habis (100 request/hari)")
            print("    - Custom Search API belum di-enable")
            return False
            
        else:
            print(f"[X] Error: Status code {response.status_code}")
            print(f"    Response: {response.text[:200]}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"[X] Network error: {e}")
        return False
    except Exception as e:
        print(f"[X] Error: {e}")
        return False

if __name__ == "__main__":
    import sys
    import io
    # Fix encoding untuk Windows
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    
    print("=" * 60)
    print("TEST GOOGLE CUSTOM SEARCH ENGINE API")
    print("=" * 60)
    print()
    
    success = test_google_cse()
    
    print()
    print("=" * 60)
    if success:
        print("Test berhasil! Google CSE siap digunakan.")
    else:
        print("Test gagal! Periksa konfigurasi di config.py")
    print("=" * 60)

